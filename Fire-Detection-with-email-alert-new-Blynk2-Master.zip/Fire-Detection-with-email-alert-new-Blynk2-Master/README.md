# Fire-Detection-with-email-alert-new-Blynk2

This programming code is embedding with code to create the event with new blynk2.0. 
For Complete video tutorial with live demo is available at our [YouTube channel here](https://youtu.be/T8vPXUrAfco)
